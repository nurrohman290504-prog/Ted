// Settings pages in two panes (runtime/ui/option_rows.mm): option rows on the left - an uppercase label, the value on
// the right (brighter when it isn't the default) - and the selected (controller) or hovered (mouse) row's description on
// the right, instead of tooltips. A / click changes a row (toggle / next value), left / right step it.
//
//   opt_begin("##gameplay", scale);
//   opt_section("Difficulty");
//   if (opt_toggle("One-hit KO", &g_settings.diff_ohko, false, "Any hit defeats Link.")) settings_save();
//   opt_end();
#pragma once

void opt_begin(const char *id, float scale);
void opt_section(const char *title);
bool opt_toggle(const char *label, bool *v, bool def, const char *desc);
// wrap: past the last value back to the first (and the other way); false: stops at the ends
bool opt_choice(const char *label, int *v, const char *const *names, int n, int def, const char *desc, bool wrap = true);
// steps of `step` between lo and hi; fmt formats the value (e.g. "%gx")
bool opt_slider(const char *label, float *v, float lo, float hi, float step, float def, const char *fmt, const char *desc);
// whole numbers lo..hi in steps of `step` (holding left / right speeds up); fmt formats it (e.g. "%d rupees"), lo_name
// (if given) is shown for lo instead (e.g. "Any")
bool opt_int(const char *label, int *v, int lo, int hi, int step, int def, const char *fmt, const char *desc,
             const char *lo_name = NULL);
// an action: true when activated
bool opt_button(const char *label, const char *desc);
// one of a set of choices (a ring on the right, filled when selected); true when chosen
bool opt_radio(const char *label, bool selected, const char *desc);
// an action / item row with a value on the right (upper: the label in capitals, as option rows; false: as written,
// e.g. a seed name); true when activated
bool opt_action(const char *label, const char *value, const char *desc, bool upper = true);
// text: the value shown on the right (hint when empty); A / click turns the row into a text field (the on-screen
// keyboard with a controller). True when Enter / the keyboard confirmed a change.
#include <stddef.h>
bool opt_text(const char *label, char *buf, size_t cap, const char *hint, const char *desc);
// that text row is being edited (its buffer is the user's: don't overwrite it)
bool opt_text_editing(const char *label);
// the next row is shown greyed out and can't be changed (e.g. forced by the seed)
void opt_disable_next(void);
// rows after this sit one step in (+1) or back out (-1): options that belong to the row above
void opt_indent(int step);
void opt_end(void);
// the next page's first row takes the controller's cursor (Down on the tab bar: ImGui's own pick across the nested
// panes was unreliable - some tabs went to a row further down, some nowhere). Cleared by the next opt_begin / call.
void opt_focus_first(bool on);

// Android: call inside each scrollable child before drawing its controls.
void ui_touch_scroll();

// The Sheikah look's pieces (design/sheikah-settings-v1), for the menu's frame (menu.mm): a frame with cut corners
// (outline / filled), a diamond, the Sheikah eye
struct ImDrawList;
struct ImVec2;
void ui_sheikah_frame(ImDrawList *dl, ImVec2 a, ImVec2 b, unsigned int col, float cut, float thickness);
void ui_sheikah_frame_filled(ImDrawList *dl, ImVec2 a, ImVec2 b, unsigned int col, float cut);
void ui_sheikah_diamond(ImDrawList *dl, ImVec2 c, float r, unsigned int col, bool filled);
void ui_sheikah_eye(ImDrawList *dl, ImVec2 p, float size, unsigned int col, float thickness);
// a section's title in the Sheikah look: small capitals in gold, a line after it (opt_section; other pages' headings)
void ui_sheikah_heading(const char *title, float scale);
